JPA durch Spring gemanaged + deklarative Transaktionsunterstützung

+ Repository-Generierung mit individuellen Ergänzungen (inklusive native Queries und Streamable Result)

