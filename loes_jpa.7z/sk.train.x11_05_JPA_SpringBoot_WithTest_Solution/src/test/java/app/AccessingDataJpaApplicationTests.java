package app;

import app.dao.EmpService;
import app.model.Employee;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import jakarta.persistence.EntityManager;
import javax.sql.DataSource;
import java.math.BigDecimal;
import java.util.Date;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
//@DataJpaTest
class AccessingDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}


	@Autowired private ApplicationContext ctx;
	@Autowired private DataSource dataSource;
	@Autowired private JdbcTemplate jdbcTemplate;
	@Autowired private EntityManager em;
	@Autowired
	private EmpService myserv;

	@Test
	void datasource_jdbctemplate_entitymanager_repository_not_null() {
		assertThat( dataSource ).isNotNull();
		assertThat( jdbcTemplate ).isNotNull();
		assertThat( em ).isNotNull();
	}
	

	@Test
	void crudTest() {
		
		Employee emp = new Employee();
		emp.setEmployeeId(471);
		emp.setFirstName("Max");
		emp.setLastName("Mustermann");
		emp.setHireDate(new Date());
		emp.setJobId("IT_PROG");
		emp.setPhoneNumber("1111");
		emp.setSalary(new BigDecimal(5000L));
		emp.setEmail("Mustermann@murks.de" + 4711);
		
		
		myserv.createEmp(emp);
		
		Employee emp1 = myserv.readEmp(471);
		System.err.println(emp1);
		
		myserv.setSalaryEmp(471, new BigDecimal(8000L));
		
		emp1 = myserv.readEmp(471);
		System.err.println(emp1.getSalary());
		
		myserv.removeEmp(471);
		
		assertTrue(myserv.readEmp(471) == null);
		
		
	}
	
	

}