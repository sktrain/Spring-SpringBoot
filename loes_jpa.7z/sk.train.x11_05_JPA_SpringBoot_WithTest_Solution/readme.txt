JPA durch Spring gemanaged + deklarative Transaktionsunterstützung,
aber jetzt via SpringBoot realisiert: wir brauchen keine Konfig mehr für diesen Fall.
Nur noch die DB-Properties für Spring-Boot.

+ klassischer Test via Junit mittels "@SpringBootTest"

Anmerkung: Sofern wir hier auf "@DataJpaTest" wechseln, um nur den Repository-Layer zu testen,
muss der "CommandLineRunner" aus der Konfig entfernt werden, da dieser im Starter enthalten ist
und versucht wird, diesen zu erzeugen. Das scheitert aber, da er nicht zu den für den Test notwendigen
Komponenten gehört (hier steht sich Spring ein wenig selbst im Weg!).

