package sk.train.app;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import sk.train.dao.EmpService;


@Configuration
public class ApplConfig {
	
	
	//Entity-Manager bereit stellen
	@Bean
	public EntityManager getEntityManager() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Muster_JPA_Hibernate_H2_Local");
		 EntityManager em = emf.createEntityManager();
		 return em;
	}
	
	//EmpService bereit stellen
	@Bean 
	public EmpService getEmpService() {
		return new EmpService(getEntityManager());
	}
	
}
