package sk.train.demo_scopes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.web.context.WebApplicationContext;
import sk.train.demo_scopes.beans.ApplicationBean;
import sk.train.demo_scopes.beans.RequestBean;
import sk.train.demo_scopes.beans.SessionBean;

@SpringBootApplication
public class DemoDependenciesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoDependenciesApplication.class, args);
	}

	@Bean
	@Autowired
	public ServletRegistrationBean<MyServlet> helloServ(ServletWebServerApplicationContext ctx){
		return new ServletRegistrationBean<>(
				new MyServlet(ctx), "/dependencies"
		);
	}

	@Bean(name ="requestBean")
	@Scope(WebApplicationContext.SCOPE_REQUEST)
	public RequestBean requestBean() {
		return new RequestBean(sessionBean());
	}

	@Bean(name ="sessionBean")
	@Scope(WebApplicationContext.SCOPE_SESSION)
	public SessionBean sessionBean() {
		return new SessionBean(applicationBean());
	}

	@Bean(name ="applicationBean")
	@Scope(WebApplicationContext.SCOPE_APPLICATION)
	public ApplicationBean applicationBean() {
		return new ApplicationBean();
	}
}
