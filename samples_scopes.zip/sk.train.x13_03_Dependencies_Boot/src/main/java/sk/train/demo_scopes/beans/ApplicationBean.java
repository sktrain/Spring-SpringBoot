package sk.train.demo_scopes.beans;

public class ApplicationBean {
	public ApplicationBean() {
		System.out.println(this.getClass().getSimpleName() + "()");
	}
}
