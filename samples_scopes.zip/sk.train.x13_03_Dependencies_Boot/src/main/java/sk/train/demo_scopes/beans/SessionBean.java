package sk.train.demo_scopes.beans;

public class SessionBean {
	private final ApplicationBean applicationBean;
	public SessionBean(ApplicationBean singletonBean) {
		System.out.println(this.getClass().getSimpleName() + "()");
		this.applicationBean = singletonBean;
	}
	public ApplicationBean getApplicationBean() {
		return this.applicationBean;
	}
}
