package sk.train.demo_scopes.beans;

public class RequestBean {
	private final SessionBean sessionBean;
	public RequestBean(SessionBean sessionBean) {
		System.out.println(this.getClass().getSimpleName() + "()");
		this.sessionBean = sessionBean;
	}
	public SessionBean getSessionBean() {
		return this.sessionBean;
	}
}
