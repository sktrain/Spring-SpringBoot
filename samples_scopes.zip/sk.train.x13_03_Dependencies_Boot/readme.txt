Spring Boot Servlet Projekt:
Boot-Variante zu sk.train.x1303_Dependencies



Port des Embbedded Tomcat ist vorsichtshalber auf "8888" gesetzt.
(siehe application.properties)