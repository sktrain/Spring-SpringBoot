package sk.train.demo_scopes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.web.context.WebApplicationContext;
import sk.train.demo_scopes.beans.MyBean;

@SpringBootApplication
public class DemoScopesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoScopesApplication.class, args);
	}

	@Bean
	@Autowired
	public ServletRegistrationBean<MyServlet> helloServ(ServletWebServerApplicationContext ctx){
		return new ServletRegistrationBean<>(
				new MyServlet(ctx), "/scopes"
		);
	}

	@Bean(name ="requestBean")
	// @Scope("request")
	@Scope(WebApplicationContext.SCOPE_REQUEST)
	public MyBean requestBean() {
		return new MyBean("request");
	}
	@Bean(name ="sessionBean")
	// Scope("session")
	@Scope(WebApplicationContext.SCOPE_SESSION)
	public MyBean sessionBean() {
		return new MyBean("session");
	}
	@Bean(name ="applicationBean")
	//@Scope("application")
	@Scope(WebApplicationContext.SCOPE_APPLICATION)
	public MyBean applicationBean() {
		return new MyBean("application");
	}
	@Bean(name ="singletonBean")
	@Scope("singleton")
	public MyBean singletonBean() {
		return new MyBean("singleton");
	}

}
