package sk.train.servlets;

//import beans.MessageBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;
import sk.train.beans.MessageBean;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	//with programmatic registration possible: context by constructor
	private ApplicationContext rootContext;

	public MyServlet(ConfigurableApplicationContext ctx) {
		this.rootContext = rootContext;
	}

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws IOException, ServletException {
		
		response.setContentType("text/plain");
		final PrintWriter out = response.getWriter();

		final HttpSession session = request.getSession();
		final ServletContext servletContext = session.getServletContext();
		Enumeration<String> enumeration = servletContext.getAttributeNames();
		while(enumeration.hasMoreElements()){
			out.println(enumeration.nextElement());
		}
		final String applContextName = "org.springframework.web.context.WebApplicationContext.ROOT";
		final WebApplicationContext ctx1 = (WebApplicationContext)servletContext.getAttribute(applContextName);
		
		final WebApplicationContext ctx2 = ContextLoader.getCurrentWebApplicationContext();
		out.println(ctx1);
		out.println(ctx2);
		out.println(ctx1 == ctx2);
		out.println(ctx1 == rootContext);

		final MessageBean bean = ctx1.getBean(MessageBean.class);
		out.println(bean.getMessage());
		out.println(servletContext.getAttribute("messageBean"));
	}
}
