package sk.train;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import sk.train.beans.MessageBean;
import sk.train.servlets.MyServlet;

@SpringBootApplication
public class DemoServletApplication {

    public static void main(String[] args) {

        ConfigurableApplicationContext ctx = SpringApplication.run(DemoServletApplication.class, args);
//        String[] names = ctx.getBeanDefinitionNames();
//        for (String s: names) {
//            System.err.println(s);
//        }
    }

    @Bean
    @Autowired
    public ServletRegistrationBean<MyServlet> helloServ(ConfigurableApplicationContext ctx){
        return new ServletRegistrationBean<>(
                new MyServlet(ctx), "/Hello"
        );
    }

    @Bean
    @Scope("application" )
    public MessageBean messageBean(){
        return new MessageBean();
    }


}
