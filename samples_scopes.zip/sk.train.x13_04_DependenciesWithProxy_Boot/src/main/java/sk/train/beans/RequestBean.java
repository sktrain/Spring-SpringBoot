package sk.train.beans;

public class RequestBean {
	public RequestBean() {
		System.out.println(this.getClass().getSimpleName() + "()");
	}
}
