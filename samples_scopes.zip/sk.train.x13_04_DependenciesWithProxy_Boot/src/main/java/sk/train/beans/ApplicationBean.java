package sk.train.beans;

public class ApplicationBean {
	private final SessionBean sessionBean;
	public ApplicationBean(SessionBean sessionBean) {
		System.out.println(this.getClass().getSimpleName() + "()");
		this.sessionBean = sessionBean;
	}
	public SessionBean getSessionBean() {
		return this.sessionBean;
	}
}
