Spring Boot Servlet Projekt:
Boot-Variante zu sk.train.x1304_DependenciesWithProxy



Port des Embbedded Tomcat ist vorsichtshalber auf "8888" gesetzt.
(siehe application.properties)