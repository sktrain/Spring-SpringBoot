package appl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import ifaces.MathService;

import static org.junit.Assert.*;

//Extend the test with Spring test support
@RunWith(SpringRunner.class)
//ApplicationContext to use
@ContextConfiguration(locations = {"/spring.xml"})

public class ApplicationTest {
	
	@Autowired
	private ApplicationContext ctx;
	
	@Test
	public void contextLoads() {
		assertNotNull("Context wurde nicht geladen", ctx);
	}
	
	@Test
	public void MathServiceTest() {
		final MathService mathService1 = ctx.getBean(MathService.class); 
		assertEquals(42, mathService1.sum(40, 2));
		assertEquals(38, mathService1.diff(40, 2));
	}
	
	@Test
	public void MathServiceSingletonTest() {
		final MathService mathService1 = ctx.getBean(MathService.class); 
		final MathService mathService2 = ctx.getBean(MathService.class);
		assertSame(mathService1, mathService2);
		
	}
	
}
