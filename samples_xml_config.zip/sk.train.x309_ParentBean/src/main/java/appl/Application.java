package appl;

import org.springframework.beans.BeansException;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import ifaces.MathService;

public class Application {
	public static void main(String[] args) {
		try (final ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml")) {
			
			try {
				final MathService mathService = ctx.getBean("mathService", MathService.class);
				System.out.println(mathService.sum(40, 2));
			} catch (BeansException e1) {
				e1.printStackTrace();
			}
			
			final MathService mathServiceA = ctx.getBean("mathServiceA", MathService.class);
			System.out.println(mathServiceA.sum(99, 2));
			try {
				System.out.println(mathServiceA.sum(999, 2));
			}
			catch(Exception e) {
				System.out.println("Expected: " + e.getMessage());
			}
			
			final MathService mathServiceB = ctx.getBean("mathServiceB", MathService.class);
			System.out.println(mathServiceB.sum(9, 2));
			try {
				System.out.println(mathServiceB.sum(99, 2));
			}
			catch(Exception e) {
				System.out.println("Expected: " + e.getMessage());
			}
		}
	}
}
