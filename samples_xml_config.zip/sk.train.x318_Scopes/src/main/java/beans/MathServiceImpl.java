package beans;

import ifaces.MathService;

public class MathServiceImpl implements MathService {

	public MathServiceImpl() {

	}
	public int sum(int x, int y) {
		return x + y;
	}
	public int diff(int x, int y) {
		return x - y;
	}
}
