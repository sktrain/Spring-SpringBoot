package beans;

import ifaces.SumService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SumServiceImpl implements SumService {

	private static Logger logger = LoggerFactory.getLogger("sk.train");
	public SumServiceImpl() { 
		logger.info("Konstruktor {}", this.getClass());
	}
	@Override
	public int sum(int x, int y) {
		return x + y;
	}
}
