package appl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import ifaces.MathService;

public class Application {
	public static void main(String[] args) {
		try (final ClassPathXmlApplicationContext ctx = 
				new ClassPathXmlApplicationContext("spring.xml")) {
			
			final MathService mathService1 = ctx.getBean("mathService1", MathService.class);
			System.out.println(mathService1.sum(40, 2));
			System.out.println(mathService1.diff(80, 3));

			final MathService mathService2 = ctx.getBean("mathService2", MathService.class);
			System.out.println(mathService2.sum(40, 2));
			System.out.println(mathService2.diff(80, 3));
		}
	}
}
