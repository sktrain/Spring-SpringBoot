package beans;

import ifaces.DiffService;

public class DiffServiceImpl implements DiffService {
	public void preDestroy() {
		System.out.println("preDestroy");
	}
	public DiffServiceImpl() {  

	}
	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
