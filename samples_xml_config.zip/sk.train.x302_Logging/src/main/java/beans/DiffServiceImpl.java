package beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ifaces.DiffService;

public class DiffServiceImpl implements DiffService {
	
	private static Logger logger = LoggerFactory.getLogger("sk.train");
	
	public DiffServiceImpl() {  
		logger.info("DiffServiceImpl.Konstruktor");
	}
	
	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
