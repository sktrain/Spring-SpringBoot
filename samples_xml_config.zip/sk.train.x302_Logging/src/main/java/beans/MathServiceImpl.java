package beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;


public class MathServiceImpl implements MathService {
	
	private static Logger logger = LoggerFactory.getLogger("sk.train");
	
	private final SumService sumService;
	private final DiffService diffService;
	
	public MathServiceImpl(SumService sumService, DiffService diffService) {
		logger.info("MathServiceImpl.Konstruktor");
		this.sumService = sumService;
		this.diffService = diffService;
	}
	
	@Override
	public int sum(int x, int y) {
		return this.sumService.sum(x, y);
	}

	@Override
	public int diff(int x, int y) {
		return this.diffService.diff(x, y);
	}
}
