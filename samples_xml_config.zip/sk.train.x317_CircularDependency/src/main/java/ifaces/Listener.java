package ifaces;

public interface Listener {
	public abstract void notify(String msg);
}
