package beans;

import ifaces.DiffService;

public class DiffServiceImpl implements DiffService {
	public DiffServiceImpl() {  

	}
	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
