package appl;

import javax.swing.JFrame;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import util.GuiParams;

public class Application {
	public static void main(String[] args) {
		try (final ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml")) {
			final GuiParams gui = ctx.getBean(GuiParams.class);
			new JFrame(gui.title) {
				private static final long serialVersionUID = 1L;
				{
					this.setBounds(gui.x, gui.y, gui.width, gui.height);
					this.getContentPane().setBackground(gui.background);
					this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					this.setVisible(true);
				}
			};
		}
	}
}
