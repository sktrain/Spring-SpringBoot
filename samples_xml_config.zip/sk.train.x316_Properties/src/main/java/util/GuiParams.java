package util;

import java.awt.Color;

public class GuiParams {
	
	public final String title;
	public final int x;
	public final int y;
	public final int width;
	public final int height;
	public final Color background;
	
	public GuiParams(String title, int x, int y, int width, int height, Color background) {
		this.title = title;
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.background = background;
	}
	@Override
	public String toString() {
		return this.getClass().getSimpleName() + 
				" [" + this.title + ", " + this.x + ", " + this.y + ", " + this.width + ", " + this.height + ", " + this.background + "]";
	}
	
	
}
