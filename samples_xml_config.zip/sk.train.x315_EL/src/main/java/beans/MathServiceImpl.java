package beans;

import ifaces.MathService;
import jn.util.Log;

public class MathServiceImpl implements MathService {

	private int max = Integer.MAX_VALUE;

	public void setMax(int max) {
		Log.log(max);
		this.max = max;
	}

	public int getMax() {
		Log.log();
		return this.max;
	}

	@Override
	public int sum(int x, int y) {
		if (x > this.max || y > this.max)
			throw new RuntimeException("too large numbers");
		return x + y;
	}

	@Override
	public int diff(int x, int y) {
		if (x > this.max || y > this.max)
			throw new RuntimeException("too large numbers");
		return x - y;
	}
}
