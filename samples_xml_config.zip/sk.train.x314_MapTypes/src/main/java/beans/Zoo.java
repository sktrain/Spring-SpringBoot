package beans;

import java.util.Map;
import java.util.Properties;

import jn.util.Log;

public class Zoo {
	
	private Properties props;
	private Map<String,String> stringMap;
	private Map<String,Language> languageMap;

	public void setProps(Properties props) {
		Log.log(props);
		this.props = props;
	}
	public void setStringMap(Map<String,String> stringMap) {
		Log.log(stringMap);
		this.stringMap = stringMap;
	}
	public void setLanguageMap(Map<String,Language> languageMap) {
		Log.log(languageMap);
		this.languageMap = languageMap;
	}
	
	public void print() {
		this.props.forEach((k, v) -> System.out.println(k + " --> " + v));
		System.out.println();
		this.stringMap.forEach((k, v) -> System.out.println(k + " --> " + v));
		System.out.println();
		this.languageMap.forEach((k, v) -> System.out.println(k + " --> " + v));
		System.out.println();
	}
}
