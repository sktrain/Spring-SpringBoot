package util;

import java.awt.Point;
import java.beans.PropertyEditorSupport;

public class PointEditor extends PropertyEditorSupport {
	private Point point;
	@Override
	public Point getValue() {  //ab Java 6 ist speziellerer Return-Typ erlaubt
	//public Object getValue() {
		return this.point;
	}
	@Override
	public void setValue(Object value) {
		this.point = (Point)value;
	}
	@Override
	public void setAsText(String text) {
		try {
			String[] tokens = text.split(":");
			this.point = new Point(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[0]));
		}
		catch(Exception e) {
			throw new IllegalArgumentException(e);
		}
	}
}
