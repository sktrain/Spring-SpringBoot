package beans;

import ifaces.SumService;

public class SumServiceImplSimple implements SumService {
	
	public SumServiceImplSimple() { 
	}
	
	@Override
	public int sum(int x, int y) {
		return x + y;
	}
}
