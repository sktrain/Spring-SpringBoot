package appl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import beans.DiffServiceImpl;
import beans.SumServiceImplRecursive;
import beans.SumServiceImplSimple;
import ifaces.DiffService;
import ifaces.SumService;

@Configuration
public class ApplConfigSumDiff {

	public ApplConfigSumDiff() {
	}
	
	@Bean(name="sumServiceSimple")
	public SumService sumServiceSimple() {
		return new SumServiceImplSimple();
	}

	@Bean(name="sumServiceRecursive")
	public SumService sumServiceRecursive() {
		return new SumServiceImplRecursive();
	}

	@Bean 
	public DiffService diffService() {
		return new DiffServiceImpl();
	}
}
