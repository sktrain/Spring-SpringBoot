package somewhere;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import beans.DiffServiceImpl;
import beans.SumServiceImpl;
import ifaces.DiffService;
import ifaces.SumService;

@Configuration
public class SumDiffConfiguration {

	public SumDiffConfiguration() {
	}
	
	@Bean 
	public SumService getSumService() {
		return new SumServiceImpl();
	}

	@Bean 
	public DiffService getDiffService() {
		return new DiffServiceImpl();
	}
}
