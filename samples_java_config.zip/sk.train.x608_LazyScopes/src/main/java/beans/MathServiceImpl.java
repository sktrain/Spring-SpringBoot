package beans;

import ifaces.MathService;

public class MathServiceImpl implements MathService {

	public MathServiceImpl() {
	}
	
	@Override
	public int sum(int x, int y) {
		return x + y;
	}
	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
