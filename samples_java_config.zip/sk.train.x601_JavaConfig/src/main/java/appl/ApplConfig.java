package appl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import beans.DiffServiceImpl;
import beans.MathServiceImpl;
import beans.SumServiceImpl;
import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;

@Configuration
public class ApplConfig {
	
	private static Logger logger = LoggerFactory.getLogger("sk.train");
	
	public ApplConfig() {
		logger.info("Konstruktor {}", this.getClass());
	}
	
	@Bean(name="sum")
	public SumService sumService() {
		return new SumServiceImpl();
	}
	
	@Bean
	public SumService sumService2() {
		return new SumServiceImpl();
	}
	
	@Bean
	public DiffService diffService() {
		return new DiffServiceImpl();
	}
	

	@Bean
	public MathService mathService() {
		return new MathServiceImpl(this.sumService2(), this.diffService());
	}
}
