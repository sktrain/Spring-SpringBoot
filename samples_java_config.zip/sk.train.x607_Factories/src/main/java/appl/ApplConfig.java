package appl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;


@Configuration
public class ApplConfig {
	
	public ApplConfig() {
	}

	@Bean(name = "Hello")
	public String hello() {
		return "Hello";
	}

	@Bean(name = "World")
	@Lazy
	public String world() {
		return "World";
	}
}
