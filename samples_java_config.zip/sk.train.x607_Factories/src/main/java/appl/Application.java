package appl;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Application {
	public static void main(String[] args) {
		try (final AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext("appl")) {
			System.out.println("-----------------------------");
			final String hello = ctx.getBean("Hello", String.class);
			System.out.println(hello);
			final String world = ctx.getBean("World", String.class);
			System.out.println(world);
		}
	}
}
