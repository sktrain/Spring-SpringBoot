Uebungen:

1) Umstellung der bisherigen 11_01-Variante auf Spring-Konfiguration:
Simple Variante, bei der lediglich die Komponenten durch Spring erzeugt und verwaltet werden.
Somit: Entity-Manager und EmpService anhand Context beziehen und nutzen.



2) Umstellung: JPA durch Spring gemanaged + deklarative Transaktionsunterstützung



3) Umstellung auf Spring Boot



4) Statt main-Methode, jetzt mal als Test



4) Erweiterung: JPA durch Spring gemanaged + deklarative Transaktionsunterstützung
  + Repository-Generierung (Vorsicht: Namensabhängigkeit zur EntityManagerFactory (default), siehe API-Doc zu
  org.springframework.data.jpa.repository.config.EnableJpaRepositories)
    Es wird weitere Dependency benötigt:
  <!-- for repository generation -->
  		<dependency>
  			<groupId>org.springframework.data</groupId>
  			<artifactId>spring-data-jpa</artifactId>
  			<version>2.6.0</version>
  		</dependency>




5) Erweiterung: Repository-Generierung mit individuellen Ergänzungen
(sowohl als reines Spring als auch Spring Boot Projekt möglich)

    - alle Angestellten mit einem gegebenen Gehalt

    - alle Angestellten mit einem Gehalt kleiner als ein gegebener Wert

    - Angestellter anhand ID + Gehaltswert

    - Summe aller Gehälter

    - Liste aller Nachnamen + Vorname

    - Liste aller Nachnamen + Vorname mit Mapping auf passende Klasse

    - Liste aller Chefs, d.h. alle die irgendjemands Chef sind, wahlweise als JPQL-Query
      oder nativer SQL-Query
      Hinweis: 	select * from employees where
                     employee_id in (select distinct manager_id from employees)

    -  alle, die keine Chefs sind (Indianer), wahlweise als JPQL-Query
       oder nativer SQL-Query

    - bei Bedarf weitere
