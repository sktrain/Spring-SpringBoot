Uebungen:

1) Umstellung der bisherigen 11_01-Variante auf Spring-Konfiguration:
Simple Variante, bei der lediglich die Komponenten durch Spring erzeugt und verwaltet werden.
Somit: Entity-Manager und EmpService anhand Context beziehen und nutzen.



2) Umstellung: JPA durch Spring gemanaged + deklarative Transaktionsunterstützung




3) Erweiterung: JPA durch Spring gemanaged + deklarative Transaktionsunterstützung
  + Repository-Generierung (Vorsicht: Namensabhängigkeit zur EntityManagerFactory (default), siehe API-Doc zu
  org.springframework.data.jpa.repository.config.EnableJpaRepositories)
    Es wird weitere Dependency benötigt:
  <!-- for repository generation -->
  		<dependency>
  			<groupId>org.springframework.data</groupId>
  			<artifactId>spring-data-jpa</artifactId>
  			<version>2.6.0</version>
  		</dependency>




4) Erweiterung: Repository-Generierung mit individuellen Ergänzungen

    - alle Angestellten mit einem gegebenen Gehalt

    - alle Angestellten mit einem Gehalt kleiner als ein gegebener Wert

    - Angestellter anhand ID + Gehaltswert

    - Summe aller Gehälter

    - nach Bedarf weitere, z.B. weitere aus unserer Lösung zum Repository ohne Spring-Unterstützung ...
