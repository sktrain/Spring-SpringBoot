package beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;

@Component
// @Component("Math")
public class MathServiceImpl implements MathService {
	
	private SumService sumService;
	private DiffService diffService;

	public MathServiceImpl() {
	}

//	@Autowired
//	public void schall(SumService sumService) { 
//
//		this.sumService = sumService;
//	}
//	
//	@Autowired
//	public void rauch(DiffService diffService) {
//		
//		this.diffService = diffService;
//	}

	@Autowired(required=false) // REQUIRED
	// @Inject // Alternative. Add to classpath: CDI-user-lib
	public void schallUndRauchh(SumService sumService) { 
		this.sumService = sumService;		
	}
	
	@Autowired // REQUIRED
	// @Inject // Alternative. Add to classpath: CDI-user-lib
	public void schallUndRauchh(DiffService diffService) { 
		this.diffService = diffService;
	}

	@Override
	public int sum(int x, int y) {
		return this.sumService.sum(x, y);
	}

	@Override
	public int diff(int x, int y) {
		return this.diffService.diff(x, y);
	}
}
