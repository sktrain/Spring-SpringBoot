package beans;

import org.springframework.stereotype.Component;

import ifaces.SumService;

//@Component
public class SumServiceImpl implements SumService {
	
	public SumServiceImpl() { 
	}
	
	@Override
	public int sum(int x, int y) {
		return x + y;
	}
}
