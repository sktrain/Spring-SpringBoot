package beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import ifaces.DiffService;

@Component
public class DiffServiceImpl implements DiffService {
	
	private static Logger logger = LoggerFactory.getLogger("sk.train");
	
	public DiffServiceImpl() { 
	}
	
	@PostConstruct
	public void postConstruct() {
		logger.info("postConstruct {}", this.getClass());		
	}
	
	@PreDestroy
	public void preDestroy() {
		logger.info("preDestroy {}", this.getClass());
	}
	
	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
