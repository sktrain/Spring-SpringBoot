package appl;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import beans.Genre;
import ifaces.MathService;

@Component
public class Application {
	
	public static void main(String[] args) {
		try (final AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext("appl", "beans")) {
			final Application application = ctx.getBean(Application.class);
			application.run();
		}
	}

   //@Resource  (name = "mathServiceSimple")
	@Autowired
	//@Qualifier("mathServiceSimple")
	@Genre("X")
	private MathService math;

//	private MathService mathServiceSimple;
//
//	@Resource(name = "mathServiceSimple")
//	public void setMathServiceSimple(MathService mathService) {
//		Log.log(mathService);
//		this.mathServiceSimple = mathService;
//	}

//	@Resource(name = "mathServiceRecursive")
//	private MathService mathServiceRecursive;

	private MathService mathServiceRecursive;

	// @Resource(name = "mathServiceRecursive")
	@Autowired
	@Qualifier("mathServiceRecursive")
	public void setMathServiceRecursive(MathService mathService) {
		this.mathServiceRecursive = mathService;
	}

	private void run() {
		System.out.println(math.getClass());
		System.out.println(math.sum(40, 2));
		System.out.println(math.diff(80, 3));
		System.out.println(mathServiceRecursive.getClass());
		System.out.println(mathServiceRecursive.sum(40, 2));
		System.out.println(mathServiceRecursive.diff(80, 3));
	}
}
