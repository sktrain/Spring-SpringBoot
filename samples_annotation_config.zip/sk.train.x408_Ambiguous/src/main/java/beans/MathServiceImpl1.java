package beans;

import org.springframework.stereotype.Component;

import ifaces.MathService;

@Component("mathServiceSimple")
@Genre(value="X")
public class MathServiceImpl1 implements MathService {
	
	public MathServiceImpl1() {
	}
	
	@Override
	public int sum(int x, int y) {
		return x + y;
	}

	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
