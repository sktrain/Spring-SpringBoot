package beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import ifaces.SumService;


@Service
//@Component
public class SumServiceImpl implements SumService {
	
	private static Logger logger = LoggerFactory.getLogger("sk.train");
	
	public SumServiceImpl() { 
		logger.info("Konstruktor {}", this.getClass());
	}
	@Override
	public int sum(int x, int y) {
		return x + y;
	}
}
