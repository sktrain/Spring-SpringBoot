package beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;

//@Component
@Component("Math")
public class MathServiceImpl implements MathService {
	
	private static Logger logger = LoggerFactory.getLogger("sk.train");
	
	private final SumService sumService;
	private final DiffService diffService;

	@Autowired(required=false)
	public MathServiceImpl() {
		this(null, null);
	}

	@Autowired(required=false)  // nur notwendig, wenn noch ein anderer Konstruktor existiert...
	public MathServiceImpl(SumService sumService, DiffService diffService) {
		logger.info("Konstruktor {}", this.getClass());
		this.sumService = sumService;
		this.diffService = diffService;
	}
	
	@Override
	public int sum(int x, int y) {
		return this.sumService.sum(x, y);
	}

	@Override
	public int diff(int x, int y) {
		return this.diffService.diff(x, y);
	}
}
