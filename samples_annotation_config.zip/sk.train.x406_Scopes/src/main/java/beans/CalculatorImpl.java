package beans;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import ifaces.Calculator;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class CalculatorImpl implements Calculator {
	
	private int value;
	
	public CalculatorImpl() {
	}
	
	public void add(int value) {
		this.value += value;
	}
	
	public void subtract(int value) {
		this.value -= value;
	}
	
	public int getValue() {
		return this.value;
	}
}
