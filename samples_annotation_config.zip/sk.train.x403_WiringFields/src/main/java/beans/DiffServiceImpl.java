package beans;

import org.springframework.stereotype.Component;

import ifaces.DiffService;

@Component
public class DiffServiceImpl implements DiffService {
	
	public DiffServiceImpl() { 		
	}
	
	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
