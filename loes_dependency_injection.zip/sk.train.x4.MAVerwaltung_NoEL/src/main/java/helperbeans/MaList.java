package helperbeans;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import sk.train.ma.strategy.verwaltung.MitarbeiterVerwaltungIf;

@Component("malist")
public class MaList<Mitarbeiter> extends ArrayList<Mitarbeiter> {

	@Autowired
	public MaList(MitarbeiterVerwaltungIf mav) {
		//Cast ist notwendig
		super((Collection<Mitarbeiter>) mav.getMlist(Comparator.naturalOrder()));
//		System.err.println(this.isEmpty());

	}
	
}
