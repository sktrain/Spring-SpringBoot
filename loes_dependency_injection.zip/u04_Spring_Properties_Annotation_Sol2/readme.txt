Kommt ohne XML-Konfig aus, da das Einlesen der Properties via Annotation @PropertySource
erfolgt! Laut Doku ist allerdings diese Annotation f�r "@Configuration"-Klassen vorgesehen,
nicht explizit f�r "@Component"-Klassen.