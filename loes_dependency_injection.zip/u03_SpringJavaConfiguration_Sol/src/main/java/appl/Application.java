package appl;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import processor.GroupChangeProcessor;


public class Application {
	public static void main(String[] args) {
		try (AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(ApplConfig.class)) {
			GroupChangeProcessor p = (GroupChangeProcessor) ctx.getBean("gcp");
			p.run();
		}
	}
}
