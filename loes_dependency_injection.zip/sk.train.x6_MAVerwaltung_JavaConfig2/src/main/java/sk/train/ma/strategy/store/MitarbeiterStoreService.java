package sk.train.ma.strategy.store;

import java.time.LocalDate;
import java.util.TreeMap;

import sk.train.ma.strategy.model.Gehaltsmodell;
import sk.train.ma.strategy.model.GehaltsmodellFactoryIf;
import sk.train.ma.strategy.model.Geschlecht;
import sk.train.ma.strategy.model.Mitarbeiter;

public class MitarbeiterStoreService implements MitarbeiterStoreServiceIf {

	private TreeMap<String, Mitarbeiter> map;
	
	public MitarbeiterStoreService(GehaltsmodellFactoryIf factory) {
		map = new TreeMap<>();

		Mitarbeiter m;
		Gehaltsmodell gehaltsmodell;
		for (int i = 0; i < 100; ++i) {
			if (i % 2 == 0) {
				// Nutzung der GehaltsmodellFactory
				gehaltsmodell = factory.getGehaltsmodell("F");
				m = new Mitarbeiter(i, "Erika", "Musterfrau" + i, LocalDate.of(1976, 1 + (int) (Math.random() * 12), 1),
						LocalDate.of(2000, 1, 1), Geschlecht.W, gehaltsmodell);
				map.put(m.getPersnr(), m);
			} else {
				// Nutzung der GehaltsmodellFactory
				gehaltsmodell = factory.getGehaltsmodell("A");
				m = new Mitarbeiter(i, "Max", "Mustermann" + i, LocalDate.of(1976, 1 + (int) (Math.random() * 12), 1),
						LocalDate.of(2000, 1, 1), Geschlecht.M, gehaltsmodell);
				map.put(m.getPersnr(), m);
			}
		}
	}

	@Override
	public TreeMap<String, Mitarbeiter> getMap() {
		return map;
	}

	
}
