package sk.train.ma.strategy.store;

import java.util.TreeMap;

import sk.train.ma.strategy.model.Mitarbeiter;

public interface MitarbeiterStoreServiceIf {

	TreeMap<String, Mitarbeiter> getMap();

}