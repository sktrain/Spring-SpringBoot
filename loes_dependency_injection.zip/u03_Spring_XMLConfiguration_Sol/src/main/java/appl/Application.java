package appl;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import processor.GroupChangeProcessor;


public class Application {
	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext beanFactory = new ClassPathXmlApplicationContext("spring.xml")) {
			GroupChangeProcessor p = (GroupChangeProcessor) beanFactory.getBean("gcp");
			p.run();
		}
	}
}
