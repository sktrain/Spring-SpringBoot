package sk.train;

public interface DisplayElement {
	public void display();
}
