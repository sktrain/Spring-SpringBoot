Rest mit JPA, Spring Boot und XML-MessageFormat mit Jackson

Dazu sind weitere Bibliotheken im ClassPath nötig

Hier jetzt mit getrennten Controller-Klassen für XML und JSON. 
Fehler kommen allerdings stets im JSON-Format. 
Man kann aber auch die Einstellungen von Spring Boot anpassen, siehe:

https://www.baeldung.com/exception-handling-for-rest-with-spring


jetzt kommt noch HATEOAS-Support hinzu: weitere Bibliothek als Spring-Starter
siehe auch: https://spring.io/guides/tutorials/rest/

jetzt kommt noch Spring Data Rest hinzu: weitere Bibliothek als Spring-Starter