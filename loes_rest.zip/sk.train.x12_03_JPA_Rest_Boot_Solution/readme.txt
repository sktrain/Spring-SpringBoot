Rest mit JPA, Spring Boot und XML-MessageFormat mit Jackson

Dazu sind weitere Bibliotheken im ClassPath nötig

