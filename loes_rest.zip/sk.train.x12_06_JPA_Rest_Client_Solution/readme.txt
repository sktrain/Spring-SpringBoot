Rest-Client via RestTemplate zum Zugriff auf den Rest-Service



Auf der Serverseite:

Rest mit JPA, Spring Boot (d.h. "sk.train.x12_01_JPA_Rest_Boot_Solution")