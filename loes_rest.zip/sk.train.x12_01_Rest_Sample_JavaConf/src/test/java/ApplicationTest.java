//import app.MyWebController;
//import app.WebConfig;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.ApplicationContext;
//import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
//import org.springframework.test.context.junit.jupiter.web.SpringJUnitWebConfig;
//
//import static org.junit.jupiter.api.Assertions.*;


////Extend the test with Spring test support
//@ExtendWith(SpringExtension.class)
////ApplicationContext to use
//@ContextConfiguration(classes = {ApplConfig.class})

//compact version
//@SpringJUnitWebConfig()
//
//public class ApplicationTest {
//
//
//	@Test   //Jupiter: non-public Test-Methods are allowed
//	 void contextLoads() {
//		//assertNotNull("Context wurde nicht geladen", ctx);
//	}
//
//	@Autowired
//	private ApplicationContext webAppContext;
//
//	@Test
//	void controllerTest(){
//		String[] beannames = webAppContext.getBeanDefinitionNames();
//		for (String s: beannames){
//			System.out.println(s);
//		}
//		assertNotNull(webAppContext.getBean("myWebController"));
//	}
//}
