package app;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
		import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;



//@RestController
//@RequestMapping(path = "/Hello")
//public class MyWebController {
//
//	@GetMapping
//	public String hello() {
//		return "Hello";
//	}
//
//
//
//}

@Controller
public class MyWebController {
	@RequestMapping(value = "/welcome")
	@ResponseBody
	public String welcome() {
		return "Welcome to Spring MVC";
	}
}
