Rest mit JPA, Spring auf Basis unserer vorhandenen JPA-Loesung.
Variante von sk.train.x12_01 ohne Spring Boot Unterstuetzung
mit Nutzung von AbstractAnnotationConfigDispatcherServletInitializer.

(Maven Projekt mit aktuellen Plugin-Versionen vom Juni 2023
	+ Jupiter-Dependencies
	+ JPA2.2/Hibernate5-Dependencies
	+ Spring Web/Rest-Dependencies)