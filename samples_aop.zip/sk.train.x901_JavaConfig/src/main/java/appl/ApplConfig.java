package appl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import advices.TraceAdvices;
import beans.MathServiceImpl;
import iface.MathService;
import jn.util.Log;


@Configuration
@EnableAspectJAutoProxy
public class ApplConfig {
	
	public ApplConfig() {
		Log.log2();
	}
	
	
	@Bean
	public MathService mathService() {
		Log.log2();
		return new MathServiceImpl();
	}
	
	@Bean
	public TraceAdvices traceAdvices() {
		Log.log2();
		return new TraceAdvices();
	}
}
