package appl;

import org.springframework.context.ApplicationEvent;

public abstract class MathEvent extends ApplicationEvent {

	private static final long serialVersionUID = 1L;

	public MathEvent(Object source) {
		super(source);
	}
}
