package appl;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Application {
	public static void main(String[] args) {
		final ConfigurableApplicationContext ctx = 
				new AnnotationConfigApplicationContext("beans");

		//zum Close des Context!
		ctx.registerShutdownHook();

		//Aufbau der GUI
		new MathUI(ctx).setVisible(true);

		//Registrieren der Listener (Observer) via Lambdas
		ctx.addApplicationListener((MathEvent event) ->
				System.out.println("MathEvent  : " + event +"\n" + "Thread: " + Thread.currentThread()));

		ctx.addApplicationListener((SumEvent event) ->
				System.out.println("SumEvent   : " + event.x + " " + event.y));

		ctx.addApplicationListener((ErrorEvent event) ->
				System.out.println("ErrorEvent : " + event));

		ctx.addApplicationListener((ExitEvent event) -> {
				System.out.println("ExitEvent : " + event.getSource());
				System.out.println(Thread.currentThread());});
	}

}
