package sk.train;

import org.springframework.context.ApplicationListener;
import org.springframework.context.ConfigurableApplicationContext;

public class CurrentConditionsDisplay implements DisplayElement, ApplicationListener<WeatherData> {

	private float temperature;
	private float humidity;
	

	public CurrentConditionsDisplay(ConfigurableApplicationContext ctx) {
		super();
		ctx.addApplicationListener(this);
	}

	public void display() {
		System.out.println("Current conditions: " + temperature + "F degrees and " + humidity + "% humidity");
	}

	@Override
	public void onApplicationEvent(WeatherData event) {
		this.humidity=event.getHumidity();
		this.temperature=event.getTemperature();
		display();
		
	}

	
}
