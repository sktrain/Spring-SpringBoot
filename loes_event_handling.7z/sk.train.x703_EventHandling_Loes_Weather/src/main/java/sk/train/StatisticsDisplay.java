package sk.train;

import org.springframework.context.ApplicationListener;
import org.springframework.context.ConfigurableApplicationContext;

public class StatisticsDisplay implements ApplicationListener<WeatherData>, DisplayElement {
	
	private float maxTemp = 0.0f;
	private float minTemp = 200;
	private float tempSum= 0.0f;
	private int numReadings;
	
	public StatisticsDisplay(ConfigurableApplicationContext ctx) {
		ctx.addApplicationListener(this);
	}
	
	@Override
	public void onApplicationEvent(WeatherData event) {
		float temp = event.getTemperature();
		tempSum += temp;
		numReadings++;

		if (temp > maxTemp) {
			maxTemp = temp;
		}
		if (temp < minTemp) {
			minTemp = temp;
		}
		display();		
	}


	public void display() {
		System.out.println("Avg/Max/Min temperature = " + (tempSum / numReadings)
			+ "/" + maxTemp + "/" + minTemp);
	}

}
