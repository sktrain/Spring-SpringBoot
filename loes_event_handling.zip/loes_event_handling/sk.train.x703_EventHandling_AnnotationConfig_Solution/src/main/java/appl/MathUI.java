package appl;

import java.awt.FlowLayout;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

import org.springframework.context.ApplicationContext;

import ifaces.MathService;

public class MathUI extends JFrame {

	private static final long serialVersionUID = 1L;

	private final JTextField textFieldX = new JTextField(5);
	private final JTextField textFieldY = new JTextField(5);
	private final JButton buttonSum = new JButton("sum");
	private final JTextField textFieldResult = new JTextField(5);
	
	private final ApplicationContext ctx;
	
	public MathUI(ApplicationContext ctx) {
		this.ctx = ctx;
		this.buildUI();
		this.buttonSum.addActionListener(e -> this.onSum());
		//Registrierung eines Window-Listeners
		this.addWindowListener(new WindowListener() {

			@Override
			public void windowOpened(WindowEvent e) {}

			@Override  //wird ausgeloest bei x-Icon
			public void windowClosing(WindowEvent e) {
				e.getWindow().dispose();
			}

			@Override  //wird generell ausgeloest bei dispose()
			public void windowClosed(WindowEvent e) {
				MathUI.this.ctx.publishEvent(new ExitEvent(this));
				//jetzt die Anwendung beenden
				System.exit(0);
			}

			@Override
			public void windowIconified(WindowEvent e) {}

			@Override
			public void windowDeiconified(WindowEvent e) {}

			@Override
			public void windowActivated(WindowEvent e) {}

			@Override
			public void windowDeactivated(WindowEvent e) {}
			
		});
	}


	private void onSum() { 
		final MathService mathService = this.ctx.getBean(MathService.class);
		try {
			final int x = Integer.parseInt(this.textFieldX.getText());
			final int y = Integer.parseInt(this.textFieldY.getText());
			final int result = mathService.sum(x, y);
			this.textFieldResult.setText(String.valueOf(result));
			this.ctx.publishEvent(new SumEvent(this, x, y));
		}
		catch(final NumberFormatException e) {
			this.textFieldResult.setText("Error");
			this.ctx.publishEvent(new ErrorEvent(this));
		}
	}
	private void buildUI() {
		this.setLayout(new FlowLayout());
		this.add(this.textFieldX);
		this.add(this.textFieldY);
		this.add(this.buttonSum);
		this.add(this.textFieldResult);
		this.pack();
		//wir wollen die Kontrolle ueber das Schliessen des Fensters
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	}
}
