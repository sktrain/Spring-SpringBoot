package beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import appl.ExitEvent;
import ifaces.MathService;
import jn.util.Log;

@Service
public class MathServiceImpl implements MathService {
	
	@PostConstruct
	private void postConstruct() {
		Log.log2();
	}

	@PreDestroy
	private void preDestroy() {
		Log.log2();
	}

	@Override
	public int sum(int x, int y) {
		Log.log2(x, y);
		return x + y;
	}

	@Override
	public int diff(int x, int y) {
		return x - y;
	}
}
