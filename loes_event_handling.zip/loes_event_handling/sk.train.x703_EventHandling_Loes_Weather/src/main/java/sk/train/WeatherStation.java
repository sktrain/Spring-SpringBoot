package sk.train;

import org.springframework.context.ApplicationContext;

//dies soll das Observable sein
public class WeatherStation {

	private ApplicationContext ctx;
	private WeatherData weatherData;
		
	public WeatherStation(ApplicationContext ctx) {	
		this.ctx = ctx;
	}
	

	public void changeWeather(WeatherData weatherData) {
		this.weatherData = weatherData;
		ctx.publishEvent(weatherData);
	}
	
	
	
}
