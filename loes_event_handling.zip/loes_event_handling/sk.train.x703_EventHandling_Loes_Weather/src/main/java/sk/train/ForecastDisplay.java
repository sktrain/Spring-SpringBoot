package sk.train;

import org.springframework.context.ApplicationListener;
import org.springframework.context.ConfigurableApplicationContext;

public class ForecastDisplay implements ApplicationListener<WeatherData>, DisplayElement {
	
	private float currentPressure = 32.0f;  //entspricht 0 Grad Celsius;  
	private float lastPressure;
	

	public ForecastDisplay(ConfigurableApplicationContext ctx) {
		ctx.addApplicationListener(this);
	}
	
	@Override
	public void onApplicationEvent(WeatherData event) {
		lastPressure = currentPressure;
		currentPressure = event.getPressure(); 
		display();	
		
	}
	public void display() {
		System.out.print("Forecast: ");
		if (currentPressure > lastPressure) {
			System.out.println("Improving weather on the way!");
		} else if (currentPressure == lastPressure) {
			System.out.println("More of the same");
		} else if (currentPressure < lastPressure) {
			System.out.println("Watch out for cooler, rainy weather");
		}
	}

	

}
