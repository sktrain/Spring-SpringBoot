package sk.train.repositories;

import model.Department;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepRepository extends JpaRepository<Department, Long> {
}
