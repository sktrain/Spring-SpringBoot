package sk.train.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest()
class EmployeeServiceStarterTests {

	@Test
	void contextLoads() {
	}
	
}