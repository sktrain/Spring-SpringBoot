JPA durch Spring gemanaged + deklarative Transaktionsunterstützung

+ Repository-Generierung mit individuellen Ergänzungen

Aber jetzt via SpringBoot realisiert: wir brauchen keine Konfig mehr für diesen Fall.
Nur noch die DB-Properties für Spring-Boot.