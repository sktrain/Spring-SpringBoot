Das Beispiel soll ansatzweise zeigen, dass die Transaktionssteuerung
durch Spring auch in einer Multi-Thread-Umgebung funktioniert:

Dazu werden 2 Threads im Abstand  von einer halben Sekunde gestartet,
die jeweils die deposit und withdraw-Metode aufrufen. 
In der DAO-Implementierung wird mittels einer Hilfsmethode der aktuelle
Thread und die DB-Connection ausgegeben und dann eine Sekunde geschlafen.
