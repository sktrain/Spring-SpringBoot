package appl;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import domain.Account;
import services.AccountService;

public class Application {
	public static void main(String[] args) throws InterruptedException {
		
		try (final AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext("appl")) {
			final AccountService accountService = ctx.getBean(AccountService.class);
			
			accountService.createAccount(4711);
			accountService.createAccount(4712);
			
			final Thread t1 = new Thread(() -> {
				accountService.deposit(4711, 5000);
				accountService.withdraw(4711, 2000);
			});
			
			final Thread t2 = new Thread(() -> {
				accountService.deposit(4712, 6000);
				accountService.withdraw(4712, 3000);
			});

			t1.start();
			Thread.sleep(500);
			t2.start();

			t1.join();
			t2.join();
			
			
			final List<Account> list = accountService.findAllAccounts();
			list.forEach(System.out::println);
		}
	}

}
