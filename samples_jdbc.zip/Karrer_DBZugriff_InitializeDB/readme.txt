Umstellung des Standard-Samples auf meine H2.

