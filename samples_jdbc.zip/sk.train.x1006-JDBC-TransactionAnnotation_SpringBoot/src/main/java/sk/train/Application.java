package sk.train;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import sk.train.daos.AccountDao;
import sk.train.daos.jdbc.AccountDaoImpl;
import sk.train.domain.Account;
import sk.train.services.AccountService;
import sk.train.services.AccountServiceImpl;



@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(Application.class, args);
		
		//Arrays.asList(ctx.getBeanDefinitionNames()).forEach(System.out::println);
	}
	
	@Autowired
	private DataSource dataSource;
	
	@Bean 
	public AccountDao accountDao() {
		final AccountDaoImpl dao = new AccountDaoImpl();
		dao.setDataSource(this.dataSource);
		return dao;
	}
	
	@Bean 
	public AccountService accountService() {
		return new AccountServiceImpl(this.accountDao());
	}
	
	 @Bean
	  public CommandLineRunner demo(AccountService accountService) {
	    return (args) -> {
	    	System.out.println(accountService.getClass().getName());
			accountService.createAccount(4711);
			accountService.createAccount(4712);
			accountService.deposit(4711, 5000);
			accountService.deposit(4712, 6000);
			accountService.withdraw(4711, 2000);
			try {
				accountService.transfer(4711, 4712, 500000);
			}
			catch (final Exception e) {
				System.out.println(e);
			}
			final List<Account> list = accountService.findAllAccounts();
			list.forEach(System.out::println);
	    };
	  }

}
