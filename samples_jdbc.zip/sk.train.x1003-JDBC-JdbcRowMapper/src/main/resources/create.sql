drop table if exists account;

create table account (
	number integer,
	balance integer,
	primary key (number)
);