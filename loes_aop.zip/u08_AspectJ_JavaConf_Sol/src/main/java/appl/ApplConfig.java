package appl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import advices.Tracer;
import processor.Database;
import processor.GroupChangeProcessor;
import processor.OrderPrinter;
import processor.OrderReader;
import processor.impl.DatabaseDummy;
import processor.impl.GroupChangeProcessorImpl;
import processor.impl.SimpleOrderPrinter;
import processor.impl.SimpleOrderReader;

@Configuration
@EnableAspectJAutoProxy
public class ApplConfig {

	@Bean 
	public Tracer tracer() {
		return new Tracer();
	}
	
	
	@Bean
	public OrderReader reader() {

		SimpleOrderReader reader = new SimpleOrderReader("src/main/resources/orders.txt");
		return reader;
	}

	@Bean
	public Database database() {
		return new DatabaseDummy();
	}
	
	
	@Bean
	public OrderPrinter printer() {
		return new SimpleOrderPrinter();
	}
	
	
	@Bean(name="gcp")
	public GroupChangeProcessor gproc() {
		GroupChangeProcessorImpl gcp = new GroupChangeProcessorImpl( reader(),database(), printer());
		return gcp;
	}

}
