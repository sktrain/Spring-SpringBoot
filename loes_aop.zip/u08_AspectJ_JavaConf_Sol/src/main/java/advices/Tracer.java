package advices;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

import jn.util.JoinPointTrace;

@Aspect
public class Tracer {

	@Around("execution(* processor.impl.SimpleOrderPrinter.printPosition(..))")
	public Object aroundPrinter(ProceedingJoinPoint joinPoint) throws Throwable {
		System.err.println(joinPoint);
		final Object result = joinPoint.proceed();
		JoinPointTrace.trace("<< ", joinPoint, result);
		return result;
	}
	
	@Around("execution(* processor.impl.SimpleOrderReader.*(..))")
	public Object aroundReader(ProceedingJoinPoint joinPoint) throws Throwable {
		System.err.println(joinPoint);
		final Object result = joinPoint.proceed();
		JoinPointTrace.trace("<< ", joinPoint, result);
		return result;
	}

}
