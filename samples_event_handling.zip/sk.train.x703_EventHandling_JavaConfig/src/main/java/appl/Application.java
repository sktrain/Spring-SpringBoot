package appl;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Application {
	public static void main(String[] args) {
		final ConfigurableApplicationContext ctx = 
				new AnnotationConfigApplicationContext(ApplConfig.class);

		//zum Close des Context!
		ctx.registerShutdownHook();

	}

}
