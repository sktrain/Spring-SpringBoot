package appl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import beans.MathServiceImpl;
import ifaces.MathService;
import jn.util.Log;

import javax.annotation.PostConstruct;

@Configuration
public class ApplConfig {

	//nur zur Info
	public ApplConfig() {
		Log.log2();
	}

	@Autowired
	ConfigurableApplicationContext ctx;

	@PostConstruct
	public void initialize(){
		ctx.addApplicationListener((MathEvent event) ->
				System.out.println("MathEvent  : " + event +"\n" + "Thread: " + Thread.currentThread()));

		ctx.addApplicationListener((SumEvent event) ->
				System.out.println("SumEvent   : " + event.x + " " + event.y));

		ctx.addApplicationListener((ErrorEvent event) ->
				System.out.println("ErrorEvent : " + event));

		ctx.addApplicationListener(new MathEventListenerClassic());
	}

	@Bean
	public MathService mathService() {
		Log.log2();
		return new MathServiceImpl();
	}

	@Bean
	public MathUI mathUI() {
		Log.log2();
		return new MathUI(ctx);
	}

}
