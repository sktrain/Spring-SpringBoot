package jn.util;

public class Try {
	public static interface Runnable {
		public abstract void run() throws Throwable;
	}
	public static interface Supplier<T> {
		public abstract T get() throws Throwable;
	}
	public static void exec(Runnable runnable) {
		try {
			runnable.run();
		}
		catch(Throwable t) {
			throw new RuntimeException(t);
		}
	}
	public static <T> T exec(Supplier<T> supplier) {
		try {
			return supplier.get();
		}
		catch(Throwable t) {
			throw new RuntimeException(t);
		}
	}
}
