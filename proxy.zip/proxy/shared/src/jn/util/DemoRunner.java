package jn.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class DemoRunner {

	private final Class<?> cls;
	private final List<Method> demoMethods;

	public DemoRunner(Class<?> cls) {
		this.cls = cls;
		final List<Method> methods = new ArrayList<>();
		for (final Method m : this.cls.getDeclaredMethods()) {
			final Demo demo = m.getAnnotation(Demo.class);
			if (demo != null) {
				checkDemoMethod(m);
				methods.add(m);
			}
		}
		methods.sort(Comparator.comparing((m -> demoValue(m))));
		this.demoMethods = Collections.unmodifiableList(methods);
	}

	public void run(int... demoValues) {
		this.demoMethods.forEach(m -> {
			if (mustInvoke(m, demoValues))
				this.callMethod(m);
		});
	}

	private void callMethod(Method m) {
		printHeader(m);
		try {
			m.invoke(null);
		}
		catch (InvocationTargetException e) {
			System.err.println(e.getTargetException());
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private static void checkDemoMethod(Method m) {
		final int modifiers = m.getModifiers();
		check(m, Modifier.isPublic(modifiers), "must be public");
		check(m, Modifier.isStatic(modifiers), "must be static");
		check(m, m.getParameterCount() == 0, "mustn't have parameters");
		check(m, m.getReturnType() == void.class, "must be void");
	}

	private static void check(Method m, boolean condition, String errorText) {
		final String annotationName = Demo.class.getSimpleName();
		if (!condition)
			throw new RuntimeException("@" + annotationName + " " + m.getName() + " " + errorText);
	}

	private boolean mustInvoke(Method m, int[] demoValues) {
		if (demoValues.length == 0)
			return true;
		for (int value : demoValues)
			if (value == demoValue(m))
				return true;
		return false;
	}

	private static void printHeader(Method m) {
		final String line = "+-------------------------------------------------------";
		System.out.println(line);
		System.out.println("| (" + demoValue(m) + ") " + m.getName());
		System.out.println(line);
	}
	
	private static int demoValue(Method m) {
		return m.getAnnotation(Demo.class).value();
	}
}
