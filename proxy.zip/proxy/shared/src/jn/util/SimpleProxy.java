package jn.util;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;

public class SimpleProxy {
	@SuppressWarnings("unchecked")
	public static <T> T create(Class<T> iface, InvocationHandler handler) {
		return (T) Proxy.newProxyInstance(
				Thread.currentThread().getContextClassLoader(), 
				new Class<?>[] { iface }, 
				handler);
		
	}
}
