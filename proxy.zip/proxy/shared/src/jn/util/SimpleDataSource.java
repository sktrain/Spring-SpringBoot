package jn.util;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.logging.Logger;

import javax.sql.DataSource;

public class SimpleDataSource implements DataSource {

	private PrintWriter writer;
	private int loginTimeout;
	
	private final String driverClass;
	private final String url;
	private final String user;
	private final String password;
	
	public SimpleDataSource(String driverClass, String url, String user, String password) {
		this.driverClass = driverClass;
		this.url = url;
		this.user = user;
		this.password = password;
	}
	@Override
	public Connection getConnection() throws SQLException {
		return DriverManager.getConnection(this.url, this.user, this.password);
	}
	@Override
	public Connection getConnection(String user, String password) throws SQLException {
		throw new SQLException();
	}
	@Override
	public PrintWriter getLogWriter() throws SQLException {
		return this.writer;
	}
	@Override
	public void setLogWriter(PrintWriter writer) throws SQLException {
		this.writer = writer;
	}
	@Override
	public int getLoginTimeout() throws SQLException {
		return this.loginTimeout;
	}
	@Override
	public void setLoginTimeout(int loginTimeout) throws SQLException {
		this.loginTimeout = loginTimeout;
	}
	@Override
	public boolean isWrapperFor(Class<?> cls) throws SQLException {
		throw new UnsupportedOperationException();
	}
	@Override
	public <T> T unwrap(Class<T> cls) throws SQLException {
		throw new UnsupportedOperationException();
	}
	@Override
	public Logger getParentLogger() throws SQLFeatureNotSupportedException {
		return null;
	}
}
