package jn.util;

import java.lang.reflect.Method;

// the class is only suitable for single-threaded systems...

public class Trace {
	
	private static int indent = 0;
	
	private static void printIndent() {
		for(int i = 0; i < indent; i++)
			System.out.print("\t");
	}
	
	public static void before(Method method, Object[] parameters) {
		printIndent();
		System.out.print(method.getDeclaringClass().getSimpleName());
		System.out.print(".");
		System.out.print(method.getName());
		System.out.print("(");
		if (parameters != null) {
			for (int i = 0; i < parameters.length; i++) {
				if (i > 0)
					System.out.print(", ");
				System.out.print(parameters[i]);
			}
		}
		System.out.println(") {");
		indent++;
	}
	
	public static void after(Method method, Object result) {
		indent--;
		printIndent();
		System.out.print("}");
		if (method.getReturnType() != void.class)
			System.out.print(" -> " + result);
		System.out.println();
	}

	public static void after(Method method, Throwable throwable) {
		indent--;
		System.out.println("} => " + throwable);
	}
}



