package jn.util;

import java.util.Map.Entry;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.engine.spi.EntityEntry;
import org.hibernate.engine.spi.PersistenceContext;
import org.hibernate.internal.SessionImpl;

public class HibernateCache {

	public static void printContext(EntityManager manager) {
		final Session session = (Session)manager.getDelegate();
		final StringBuilder builder = new StringBuilder();
		builder.append(session.getClass().getName()).append("\n");
		builder.append("\t[ Dirty = " + session.isDirty() + " ]\n");
		final SessionImpl impl = (SessionImpl) session;
		final PersistenceContext ctx = impl.getPersistenceContext();
		final Entry<Object, EntityEntry>[] list = ctx.reentrantSafeEntityEntries();
		for (final Entry<Object, EntityEntry> e : list) {
			final Object obj = e.getKey();
			final EntityEntry entry = e.getValue();
			builder.append("\t" + entry.getId() + " ==> \n");
			builder.append("\t\t" + obj + "\n");
			final Object[] loadedState = entry.getLoadedState();
			if (loadedState != null) {
				builder.append("\t\tLoadedState = [");
				for (final Object value : loadedState)
					builder.append(" " + value);
				builder.append(" ]\n");
			}
			final Object[] deletedState = entry.getDeletedState();
			if (deletedState != null) {
				builder.append("\t\tDeletedState = [");
				for (final Object value : deletedState)
					builder.append(" " + value);
				builder.append(" ]\n");
			}
		}
		System.out.println(builder);
	}
}
