package jn.util;

import java.util.Properties;

public class DbProperties {
	public final String driver;
	public final String url;
	public final String user;
	public final String password;
	
	public DbProperties(String filename) {
		final Properties properties = new Properties();
		Try.exec(() -> properties.load(ClassLoader.getSystemResourceAsStream(filename)));
		this.driver = properties.getProperty("db.driver");
		this.url = properties.getProperty("db.url");
		this.user = properties.getProperty("db.user");
		this.password = properties.getProperty("db.password");
	}
}
