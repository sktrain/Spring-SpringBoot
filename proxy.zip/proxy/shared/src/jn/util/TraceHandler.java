package jn.util;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class TraceHandler implements InvocationHandler {

	private final Object target;

	public TraceHandler(Object target) {
		this.target = target;
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		if (method.getDeclaringClass() != Object.class)
			Trace.before(method, args);
		try {
			final Object result;
			if (this.target instanceof InvocationHandler)
				result = ((InvocationHandler) this.target).invoke(proxy, method, args);
			else
				result = method.invoke(this.target, args);
			if (method.getDeclaringClass() != Object.class)
				Trace.after(method, result);
			return result;
		}
		catch (InvocationTargetException e) {
			final Throwable te = e.getTargetException();
			if (method.getDeclaringClass() != Object.class)
				Trace.after(method, te);
			throw te;
		}
		catch (Throwable e) {
			if (method.getDeclaringClass() != Object.class)
				Trace.after(method, e);
			throw e;
		}
	}
}
