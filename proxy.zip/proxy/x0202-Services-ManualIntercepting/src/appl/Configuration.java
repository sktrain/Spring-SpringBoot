package appl;

import beans.DiffServiceImpl;
import beans.MathServiceImpl;
import beans.SumServiceImpl;
import ifaces.DiffService;
import ifaces.MathService;
import ifaces.SumService;
import jn.util.SimpleProxy;
import jn.util.TraceHandler;

public class Configuration {
	public static MathService createMathService() {
		final SumService sumService = SimpleProxy.create(
				SumService.class, new TraceHandler(new SumServiceImpl()));
		final DiffService diffService = SimpleProxy.create(
				DiffService.class, new TraceHandler(new DiffServiceImpl()));
		return SimpleProxy.create(
				MathService.class, new TraceHandler(new MathServiceImpl(sumService, diffService)));
	}
}
