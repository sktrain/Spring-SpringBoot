package processor.impl;

import domain.Customer;
import domain.Order;
import domain.Product;
import processor.Database;
import processor.GroupChangeProcessor;
import processor.OrderPrinter;
import processor.OrderReader;

public class GroupChangeProcessorImpl implements GroupChangeProcessor {
	
	private final OrderReader reader;
	private final Database database;
	private final OrderPrinter printer;
	
	public GroupChangeProcessorImpl(OrderReader reader, Database database, OrderPrinter printer) {
		this.reader = reader;
		this.database = database;
		this.printer = printer;
	}

	public void run() {
		Order order = this.reader.read();
		this.printer.printBegin();
		int totalSum = 0;
		while(order != null) {
			int groupSum = 0;
			int customerNumber = order.getCustomerNumber();
			Customer customer = this.database.findCustomer(customerNumber);
			this.printer.printGroupBegin(customer);
			while(order != null && order.getCustomerNumber() == customerNumber) {
				Product product = this.database.findProduct(order.getProductNumber());
				this.printer.printPosition(order, product, order.getAmount() * product.getPrice());
				groupSum += order.getAmount() * product.getPrice();
				order = this.reader.read();
			}
			this.printer.printGroupEnd(groupSum);
			totalSum += groupSum;
		}
		this.printer.printEnd(totalSum);
		reader.close();
	}
	
}
